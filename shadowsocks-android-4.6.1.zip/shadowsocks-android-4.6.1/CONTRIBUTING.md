Please check [FAQ](.github/faq.md) before submitting new issues.

And just in case you don't know,
[don't ask questions on issues](https://medium.com/@methane/why-you-must-not-ask-questions-on-github-issues-51d741d83fde).
